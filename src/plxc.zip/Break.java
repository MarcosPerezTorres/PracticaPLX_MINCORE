public class Break extends Instruccion {

    public Break(int linea){
        super(linea);
    }

    @Override
    public Objeto generarCodigo() throws Exception {
        return null;
    }
    
}
